<template>
#[[$END$]]#
</template>

<script>
export default {
name: "${COMPONENT_NAME}",
components: {},
props: {},
data() {},
computed: {},
watch: {},
created() {},
mounted() {},
destroyed() {},
methods: {},
}
</script>

<style scoped>

</style>